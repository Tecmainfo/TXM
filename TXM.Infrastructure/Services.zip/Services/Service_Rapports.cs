﻿using Microsoft.Data.Sqlite;

using TXM.Domaine.Modèles;
using TXM.Infrastructure.Base_de_données;

namespace TXM.Infrastructure.Services
    {
    public static class Service_Rapports
        {
        public static IList<Rapport> Lister()
            {
            var liste = new List<Rapport>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT id, date, type, utilisateur, fichier 
                                FROM rapports 
                                ORDER BY date DESC;";

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Rapport
                    {
                    Id = rd.GetInt32(0),
                    Date = DateTime.TryParse(rd.GetString(1), out var d) ? d : DateTime.MinValue,
                    Type = rd.GetString(2),
                    Utilisateur = rd.GetString(3),
                    NomFichier = rd.GetString(4)
                    });
                }
            return liste;
            }

        public static void Ajouter(string type, string utilisateur, string fichier)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO rapports(date, type, utilisateur, fichier) 
                                VALUES($d, $t, $u, $f);";
            cmd.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            cmd.Parameters.AddWithValue("$t", type);
            cmd.Parameters.AddWithValue("$u", utilisateur);
            cmd.Parameters.AddWithValue("$f", fichier);
            cmd.ExecuteNonQuery();
            }

        public static void Supprimer(int id)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM rapports WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", id);
            cmd.ExecuteNonQuery();
            }
        }
    }
