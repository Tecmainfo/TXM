﻿using Microsoft.Data.Sqlite;
using System.Security.Cryptography;
using System.Net.Http;
using TXM.Domaine.Modèles;
using TXM.Infrastructure.Base_de_données;
using TXM.Infrastructure.Config;

namespace TXM.Infrastructure.Services
    {
    public static class Service_Règlements
        {
        public static string Dossier_Racine =>
            Path.Combine(Configuration_Base_de_données.Dossier_App, "Reglements");

        public static IList<Règlement> Lister(int? année = null, string? filtreTexte = null)
            {
            var liste = new List<Règlement>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();

            var where = new List<string>();
            if (année.HasValue) where.Add("annee = $a");
            if (!string.IsNullOrWhiteSpace(filtreTexte))
                where.Add("(LOWER(titre) LIKE $f OR LOWER(categorie) LIKE $f)");

            cmd.CommandText = $@"
SELECT id, annee, titre, categorie, version, source_url, fichier_local, date_publication, date_ajout, hash
FROM reglements
{(where.Count > 0 ? "WHERE " + string.Join(" AND ", where) : "")}
ORDER BY annee DESC, categorie, titre;";

            if (année.HasValue) cmd.Parameters.AddWithValue("$a", année.Value);
            if (!string.IsNullOrWhiteSpace(filtreTexte))
                cmd.Parameters.AddWithValue("$f", "%" + filtreTexte.Trim().ToLower() + "%");

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Règlement
                    {
                    Id = rd.GetInt32(0),
                    Année = rd.GetInt32(1),
                    Titre = rd.GetString(2),
                    Catégorie = rd.GetString(3),
                    Version = rd.IsDBNull(4) ? "" : rd.GetString(4),
                    Source_Url = rd.IsDBNull(5) ? "" : rd.GetString(5),
                    Fichier_Local = rd.GetString(6),
                    Date_Publication = rd.IsDBNull(7) ? null : DateTime.TryParse(rd.GetString(7), out var dp) ? dp : null,
                    Date_Ajout = DateTime.TryParse(rd.GetString(8), out var da) ? da : DateTime.MinValue,
                    Hash = rd.IsDBNull(9) ? "" : rd.GetString(9)
                    });
                }
            return liste;
            }

        public static Règlement Ajouter_Depuis_Fichier(int année, string titre, string catégorie, string cheminSource, string version = "", DateTime? datePublication = null)
            {
            var dossier = Path.Combine(Dossier_Racine, année.ToString());
            Directory.CreateDirectory(dossier);

            var nom = Path.GetFileName(cheminSource);
            if (string.IsNullOrWhiteSpace(Path.GetExtension(nom))) nom += ".pdf";
            var cible = Chemin_Unique(Path.Combine(dossier, nom));

            File.Copy(cheminSource, cible, overwrite: false);
            var hash = Hash_Fichier(cible);

            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO reglements(annee, titre, categorie, version, source_url, fichier_local, date_publication, date_ajout, hash)
VALUES($a, $t, $c, $v, $u, $f, $dp, $daj, $h);
SELECT last_insert_rowid();";
            cmd.Parameters.AddWithValue("$daj", DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            cmd.Parameters.AddWithValue("$a", année);
            cmd.Parameters.AddWithValue("$t", titre);
            cmd.Parameters.AddWithValue("$c", catégorie);
            cmd.Parameters.AddWithValue("$v", version ?? "");
            cmd.Parameters.AddWithValue("$u", "");
            cmd.Parameters.AddWithValue("$f", cible);
            cmd.Parameters.AddWithValue("$dp", datePublication?.ToString("yyyy-MM-dd") ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("$h", hash);

            var id = Convert.ToInt32(cmd.ExecuteScalar());

            return new Règlement
                {
                Id = id,
                Année = année,
                Titre = titre,
                Catégorie = catégorie,
                Version = version ?? "",
                Source_Url = "",
                Fichier_Local = cible,
                Date_Publication = datePublication,
                Date_Ajout = DateTime.Now,
                Hash = hash
                };
            }

        public static async Task<Règlement> Ajouter_Depuis_Url(int année, string titre, string catégorie, string url, string version = "", DateTime? datePublication = null)
            {
            var dossier = Path.Combine(Dossier_Racine, année.ToString());
            Directory.CreateDirectory(dossier);

            using var http = new HttpClient();
            var bytes = await http.GetByteArrayAsync(url);

            var nomBase = Slug(titre);
            var cible = Chemin_Unique(Path.Combine(dossier, nomBase + ".pdf"));
            await File.WriteAllBytesAsync(cible, bytes);

            var hash = Hash_Fichier(cible);

            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO reglements(annee, titre, categorie, version, source_url, fichier_local, date_publication, date_ajout, hash)
VALUES($a, $t, $c, $v, $u, $f, $dp, $daj, $h);
SELECT last_insert_rowid();";
            cmd.Parameters.AddWithValue("$daj", DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            cmd.Parameters.AddWithValue("$a", année);
            cmd.Parameters.AddWithValue("$t", titre);
            cmd.Parameters.AddWithValue("$c", catégorie);
            cmd.Parameters.AddWithValue("$v", version ?? "");
            cmd.Parameters.AddWithValue("$u", url);
            cmd.Parameters.AddWithValue("$f", cible);
            cmd.Parameters.AddWithValue("$dp", datePublication?.ToString("yyyy-MM-dd") ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("$h", hash);

            var id = Convert.ToInt32(cmd.ExecuteScalar());

            return new Règlement
                {
                Id = id,
                Année = année,
                Titre = titre,
                Catégorie = catégorie,
                Version = version ?? "",
                Source_Url = url,
                Fichier_Local = cible,
                Date_Publication = datePublication,
                Date_Ajout = DateTime.Now,
                Hash = hash
                };
            }

        public static void MettreÀJour_Métadonnées(Règlement r)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE reglements
SET annee=$a, titre=$t, categorie=$c, version=$v, date_publication=$dp
WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", r.Id);
            cmd.Parameters.AddWithValue("$a", r.Année);
            cmd.Parameters.AddWithValue("$t", r.Titre);
            cmd.Parameters.AddWithValue("$c", r.Catégorie);
            cmd.Parameters.AddWithValue("$v", r.Version ?? "");
            cmd.Parameters.AddWithValue("$dp", r.Date_Publication?.ToString("yyyy-MM-dd") ?? (object)DBNull.Value);
            cmd.ExecuteNonQuery();
            }

        public static void Supprimer(int id)
            {
            string? fichier = null;
            using (var conn = Service_SQLite.Ouvrir())
                {
                using var cmd1 = conn.CreateCommand();
                cmd1.CommandText = "SELECT fichier_local FROM reglements WHERE id=$id;";
                cmd1.Parameters.AddWithValue("$id", id);
                fichier = cmd1.ExecuteScalar()?.ToString();
                }

            using (var conn = Service_SQLite.Ouvrir())
            using (var cmd = conn.CreateCommand())
                {
                cmd.CommandText = "DELETE FROM reglements WHERE id=$id;";
                cmd.Parameters.AddWithValue("$id", id);
                cmd.ExecuteNonQuery();
                }

            if (!string.IsNullOrWhiteSpace(fichier) && File.Exists(fichier))
                {
                try { File.Delete(fichier); } catch { /* ignore */ }
                }
            }

        public static void Ouvrir(Règlement r)
            {
            if (!File.Exists(r.Fichier_Local)) return;
            var psi = new System.Diagnostics.ProcessStartInfo
                {
                FileName = r.Fichier_Local,
                UseShellExecute = true
                };
            System.Diagnostics.Process.Start(psi);
            }

        public static string Exporter_Csv(IList<Règlement> items)
            {
            var temp = Path.Combine(Path.GetTempPath(), $"reglements_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
            using var sw = new StreamWriter(temp, false, System.Text.Encoding.UTF8);
            sw.WriteLine("Id;Année;Catégorie;Titre;Version;Date_Publication;Date_Ajout;Fichier_Local;Source_Url;Hash");
            foreach (var r in items)
                {
                string csvDatePub = r.Date_Publication?.ToString("yyyy-MM-dd") ?? "";
                sw.WriteLine($"{r.Id};{r.Année};{Esc(r.Catégorie)};{Esc(r.Titre)};{Esc(r.Version)};{csvDatePub};{r.Date_Ajout:yyyy-MM-dd HH:mm};{Esc(r.Fichier_Local)};{Esc(r.Source_Url)};{r.Hash}");
                }
            return temp;

            static string Esc(string s) => s?.Replace(";", ",") ?? "";
            }

        public static void Révéler_Dans_Explorateur(Règlement r)
            {
            if (!File.Exists(r.Fichier_Local)) return;
            try
                {
                var arg = $"/select,\"{r.Fichier_Local}\"";
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                    FileName = "explorer.exe",
                    Arguments = arg,
                    UseShellExecute = true
                    });
                }
            catch { Ouvrir(r); }
            }


        // utilitaires
        private static string Chemin_Unique(string chemin)
            {
            if (!File.Exists(chemin)) return chemin;
            var dir = Path.GetDirectoryName(chemin)!;
            var nom = Path.GetFileNameWithoutExtension(chemin);
            var ext = Path.GetExtension(chemin);
            int i = 1;
            string c;
            do { c = Path.Combine(dir, $"{nom}_{i}{ext}"); i++; }
            while (File.Exists(c));
            return c;
            }

        private static string Hash_Fichier(string chemin)
            {
            using var fs = File.OpenRead(chemin);
            using var sha = SHA256.Create();
            var hash = sha.ComputeHash(fs);
            return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
            }

        private static string Slug(string s)
            {
            var invalid = Path.GetInvalidFileNameChars();
            var clean = new string(s.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray());
            return clean.Replace(' ', '_');
            }
        }
    }
