﻿namespace TXM.Infrastructure.Services
    {
    public static class Service_Concours_Officiels
        {
        public static IList<Concours_Officiel> Lister()
            {
            var liste = new List<Concours_Officiel>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT id, nom, date, homologation, arbitre, statut 
                                FROM concours_officiels ORDER BY date DESC;";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Concours_Officiel
                    {
                    Id = rd.GetInt32(0),
                    Nom = rd.GetString(1),
                    Date = DateTime.Parse(rd.GetString(2)),
                    Numéro_Homologation = rd.GetString(3),
                    Arbitre = rd.GetString(4),
                    Statut = rd.GetString(5)
                    });
                }
            return liste;
            }

        public static Concours_Officiel? Ajouter(string nom, DateTime date, string homologation, string arbitre)
            {
            if (!Service_Restrictions.PeutAjouterConcours())
                return null;

            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO concours_officiels(nom, date, homologation, arbitre, statut) 
                        VALUES($nom, $date, $homologation, $arbitre, 'Prévu');
                        SELECT last_insert_rowid();";
            cmd.Parameters.AddWithValue("$nom", nom);
            cmd.Parameters.AddWithValue("$date", date.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("$homologation", homologation);
            cmd.Parameters.AddWithValue("$arbitre", arbitre);
            var id = Convert.ToInt32(cmd.ExecuteScalar());

            return new Concours_Officiel
                {
                Id = id,
                Nom = nom,
                Date = date,
                Numéro_Homologation = homologation,
                Arbitre = arbitre,
                Statut = "Prévu"
                };
            }

        public static void Valider(int idConcours)
            {
            if (Service_Licence.EstEnModeRestreint())
                {
                var concours = Lister().First(c => c.Id == idConcours);
                if (concours.Date.Date < DateTime.Today)
                    throw new InvalidOperationException("En mode Démo restreint, le concours doit être clôturé le jour même.");
                }

            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE concours_officiels SET statut='Homologué' WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", idConcours);
            cmd.ExecuteNonQuery();
            }

        public static void Mettre_À_Jour_Statut(int idConcours, string statut)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE concours_officiels SET statut=$statut WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", idConcours);
            cmd.Parameters.AddWithValue("$statut", statut);
            cmd.ExecuteNonQuery();
            }

        public static int CompterEnCours()
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM concours_officiels WHERE statut='En cours';";
            return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }
    }
