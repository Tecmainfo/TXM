﻿namespace TXM.Infrastructure.Services
    {
    public static class Service_Inscriptions
        {
        // Liste globale, avec info concours
        public static IList<Inscription> Lister()
            {
            var liste = new List<Inscription>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT i.id, i.nom_équipe, i.joueurs, i.id_concours, c.nom
                                FROM inscriptions i
                                JOIN concours_officiels c ON c.id = i.id_concours
                                ORDER BY c.date DESC;";

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Inscription
                    {
                    Id = rd.GetInt32(0),
                    NomÉquipe = rd.GetString(1),
                    Joueurs = rd.GetString(2),
                    IdConcours = rd.GetInt32(3),
                    NomConcours = rd.GetString(4)
                    });
                }
            return liste;
            }

        // Ajouter une inscription
        public static Inscription Ajouter(string nomÉquipe, string joueurs, int idConcours)
            {
            if (Service_Licence.EstEnModeRestreint())
                {
                var existantes = ListerPourConcours(idConcours);
                int nbJoueurs = existantes.Sum(i => i.Joueurs.Split(',', StringSplitOptions.RemoveEmptyEntries).Length);
                if (nbJoueurs >= 16)
                    throw new InvalidOperationException("Limite de 16 joueurs atteinte en mode Démo restreint.");
                }

            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO inscriptions(nom_équipe, joueurs, id_concours)
                        VALUES($nom, $joueurs, $concours);
                        SELECT last_insert_rowid();";
            cmd.Parameters.AddWithValue("$nom", nomÉquipe);
            cmd.Parameters.AddWithValue("$joueurs", joueurs);
            cmd.Parameters.AddWithValue("$concours", idConcours);
            var id = Convert.ToInt32(cmd.ExecuteScalar());

            return new Inscription { Id = id, NomÉquipe = nomÉquipe, Joueurs = joueurs, IdConcours = idConcours };
            }

        public static void MettreÀJour(int id, string nomÉquipe, string joueurs)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE inscriptions
                                SET nom_équipe=$n, joueurs=$j
                                WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", id);
            cmd.Parameters.AddWithValue("$n", nomÉquipe);
            cmd.Parameters.AddWithValue("$j", joueurs);
            cmd.ExecuteNonQuery();
            }

        // Liste des inscriptions pour un concours donné
        public static IList<Inscription> ListerPourConcours(int idConcours)
            {
            var liste = new List<Inscription>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT id, nom_équipe, joueurs, id_concours
                                FROM inscriptions
                                WHERE id_concours=$c;";
            cmd.Parameters.AddWithValue("$c", idConcours);

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Inscription
                    {
                    Id = rd.GetInt32(0),
                    NomÉquipe = rd.GetString(1),
                    Joueurs = rd.GetString(2),
                    IdConcours = rd.GetInt32(3)
                    });
                }
            return liste;
            }

        public static void Supprimer(int idInscription)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"DELETE FROM inscriptions WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", idInscription);
            cmd.ExecuteNonQuery();
            }
        }
    }
