﻿namespace TXM.Infrastructure.Services
    {
    public static class Service_Licence
        {
        private static readonly string FichierLicence =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TXM", "licence.json");

        public static Licence LicenceActuelle { get; private set; } = new Licence();

        public static void Charger()
            {
            if (!File.Exists(FichierLicence))
                {
                // Première utilisation → licence démo par défaut
                LicenceActuelle = new Licence
                    {
                    Type = TypeLicence.Demo,
                    DateActivation = DateTime.Now,
                    DateExpiration = DateTime.Now.AddMonths(1)
                    };
                Sauvegarder();
                return;
                }

            try
                {
                var json = File.ReadAllText(FichierLicence);
                LicenceActuelle = JsonSerializer.Deserialize<Licence>(json) ?? new Licence();
                }
            catch
                {
                // fallback démo
                LicenceActuelle = new Licence { Type = TypeLicence.Demo, DateActivation = DateTime.Now };
                }
            }

        public static void Sauvegarder()
            {
            Directory.CreateDirectory(Path.GetDirectoryName(FichierLicence)!);
            var json = JsonSerializer.Serialize(LicenceActuelle, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(FichierLicence, json);
            }

        public static bool EstValide()
            {
            if (LicenceActuelle.Type == TypeLicence.Demo && LicenceActuelle.DateExpiration.HasValue)
                {
                return DateTime.Now <= LicenceActuelle.DateExpiration.Value;
                }
            return true; // licences permanentes
            }

        public static bool EstEnModeRestreint()
            {
            // Démo expirée = restreint
            return LicenceActuelle.Type == TypeLicence.Demo && !EstValide();
            }
        }
    }
