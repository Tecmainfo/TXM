﻿/*
* * * * *
*  Nom du logiciel         : TXM (Infrastructure)
*  Projet Principal        : TXM
*  Auteur                  : Kano
*  Licence                 : Licence Propriétaire
*  Classification          : C3 - Développement
*  Version                 : 25.10.02.1.0
*  Nom du fichier          : Service_Homologation.cs
*  Emplacement du fichier  : TXM/TXM.Infrastructure/Services/Service_Homologation.cs
*  Description             : Service gestion homologation – enregistrement décisions, historique, mise à jour concours officiels
*  Copyright               : © 2025 Tecmainfo
* * * * *
*/

using System;
using System.Collections.Generic;

using Microsoft.Data.Sqlite;

using TXM.Domaine.Modèles;

namespace TXM.Infrastructure.Services
    {
    public static class Service_Homologation
        {
        /// <summary>
        /// Enregistre une décision d’homologation et met à jour le statut du concours.
        /// </summary>
        public static void EnregistrerDécision(int idConcours, string décision, string arbitre, string commentaire)
            {
            using var conn = Service_SQLite.Ouvrir();

            // Historique
            using (var cmd = conn.CreateCommand())
                {
                cmd.CommandText = @"
INSERT INTO homologation_historique(id_concours, date_action, décision, arbitre, commentaire)
VALUES($concours, $date, $décision, $arbitre, $commentaire);";

                cmd.Parameters.AddWithValue("$concours", idConcours);
                cmd.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("$décision", décision);
                cmd.Parameters.AddWithValue("$arbitre", arbitre ?? "");
                cmd.Parameters.AddWithValue("$commentaire", commentaire ?? "");
                cmd.ExecuteNonQuery();
                }

            // Mise à jour concours
            using (var cmd2 = conn.CreateCommand())
                {
                cmd2.CommandText = @"UPDATE concours_officiels SET statut=$statut WHERE id=$id;";
                cmd2.Parameters.AddWithValue("$id", idConcours);
                cmd2.Parameters.AddWithValue("$statut", décision);
                cmd2.ExecuteNonQuery();
                }
            }

        /// <summary>
        /// Retourne l’historique des décisions pour un concours.
        /// </summary>
        public static IList<HistoriqueHomologation> ListerPourConcours(int idConcours)
            {
            var liste = new List<HistoriqueHomologation>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT id, id_concours, date_action, décision, arbitre, commentaire
FROM homologation_historique
WHERE id_concours=$c
ORDER BY date_action DESC;";
            cmd.Parameters.AddWithValue("$c", idConcours);

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new HistoriqueHomologation
                    {
                    Id = rd.GetInt32(0),
                    IdConcours = rd.GetInt32(1),
                    DateAction = DateTime.TryParse(rd.GetString(2), out var dt) ? dt : DateTime.MinValue,
                    Décision = rd.IsDBNull(3) ? "" : rd.GetString(3),
                    Arbitre = rd.IsDBNull(4) ? "" : rd.GetString(4),
                    Commentaire = rd.IsDBNull(5) ? "" : rd.GetString(5)
                    });
                }
            return liste;
            }

        /// <summary>
        /// Retourne tout l’historique, tous concours confondus (utile export global).
        /// </summary>
        public static IList<HistoriqueHomologation> ListerTout()
            {
            var liste = new List<HistoriqueHomologation>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT id, id_concours, date_action, décision, arbitre, commentaire
FROM homologation_historique
ORDER BY date_action DESC;";

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new HistoriqueHomologation
                    {
                    Id = rd.GetInt32(0),
                    IdConcours = rd.GetInt32(1),
                    DateAction = DateTime.TryParse(rd.GetString(2), out var dt) ? dt : DateTime.MinValue,
                    Décision = rd.IsDBNull(3) ? "" : rd.GetString(3),
                    Arbitre = rd.IsDBNull(4) ? "" : rd.GetString(4),
                    Commentaire = rd.IsDBNull(5) ? "" : rd.GetString(5)
                    });
                }
            return liste;
            }
        }
    }
