﻿using Microsoft.Data.Sqlite;

using TXM.Domaine.Modèles;
using TXM.Infrastructure.Base_de_données;

namespace TXM.Infrastructure.Services
    {
    public static class Service_Sanctions
        {
        public static IList<Sanction> Lister()
            {
            var liste = new List<Sanction>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT id, date, type, motif, article_règlement, arbitre, durée_minutes, id_incident
                                FROM sanctions ORDER BY date DESC, id DESC;";

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Sanction
                    {
                    Id = rd.GetInt32(0),
                    Date = DateTime.TryParse(rd.GetString(1), out var d) ? d : DateTime.MinValue,
                    Type = rd.GetString(2),
                    Motif = rd.GetString(3),
                    Article_Règlement = rd.IsDBNull(4) ? "" : rd.GetString(4),
                    Arbitre = rd.IsDBNull(5) ? "" : rd.GetString(5),
                    Durée_Minutes = rd.IsDBNull(6) ? 0 : rd.GetInt32(6),
                    Id_Incident = rd.IsDBNull(7) ? (int?)null : rd.GetInt32(7)
                    });
                }
            return liste;
            }

        public static Sanction Ajouter(DateTime date, string type, string motif, string article, string arbitre, int duréeMinutes, int? idIncident)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO sanctions(date, type, motif, article_règlement, arbitre, durée_minutes, id_incident)
                                VALUES($d, $t, $m, $a, $arb, $dur, $inc);
                                SELECT last_insert_rowid();";
            cmd.Parameters.AddWithValue("$d", date.ToString("yyyy-MM-dd HH:mm"));
            cmd.Parameters.AddWithValue("$t", type);
            cmd.Parameters.AddWithValue("$m", motif);
            cmd.Parameters.AddWithValue("$a", article ?? "");
            cmd.Parameters.AddWithValue("$arb", arbitre ?? "");
            cmd.Parameters.AddWithValue("$dur", duréeMinutes);
            cmd.Parameters.AddWithValue("$inc", (object?)idIncident ?? DBNull.Value);
            var id = Convert.ToInt32(cmd.ExecuteScalar());

            return new Sanction
                {
                Id = id,
                Date = date,
                Type = type,
                Motif = motif,
                Article_Règlement = article,
                Arbitre = arbitre,
                Durée_Minutes = duréeMinutes,
                Id_Incident = idIncident
                };
            }

        public static void Supprimer(int idSanction)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"DELETE FROM sanctions WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", idSanction);
            cmd.ExecuteNonQuery();
            }

        public static int Compter()
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM sanctions;";
            return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }
    }
