﻿namespace TXM.Infrastructure.Services
    {
    public static class Service_Équipes
        {
        public static IList<Équipe> ListerToutes()
            {
            var liste = new List<Équipe>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT id, nom FROM équipes ORDER BY nom;";

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Équipe
                    {
                    Id = rd.GetInt32(0),
                    Nom = rd.GetString(1)
                    });
                }
            return liste;
            }

        public static Équipe? Ajouter(string nom)
            {
            if (!Service_Restrictions.PeutAjouterEquipe())
                return null;

            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO équipes(nom) VALUES($n);
                        SELECT last_insert_rowid();";
            cmd.Parameters.AddWithValue("$n", nom);
            var id = Convert.ToInt32(cmd.ExecuteScalar());

            return new Équipe { Id = id, Nom = nom };
            }

        public static void Supprimer(int id)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM équipes WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", id);
            cmd.ExecuteNonQuery();
            }

        public static void MettreÀJour(int id, string nom)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE équipes SET nom=$n WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", id);
            cmd.Parameters.AddWithValue("$n", nom);
            cmd.ExecuteNonQuery();
            }

        // === Gestion des relations équipe ↔ joueurs ===
        public static void AjouterJoueurDansÉquipe(int idÉquipe, int idJoueur)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT OR IGNORE INTO équipes_joueurs(id_équipe, id_joueur)
                                VALUES($e, $j);";
            cmd.Parameters.AddWithValue("$e", idÉquipe);
            cmd.Parameters.AddWithValue("$j", idJoueur);
            cmd.ExecuteNonQuery();
            }

        public static IList<Joueur> ListerJoueursDansÉquipe(int idÉquipe)
            {
            var liste = new List<Joueur>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT j.id, j.nom, j.licence, j.club
                FROM joueurs j
                JOIN équipes_joueurs ej ON ej.id_joueur=j.id
                WHERE ej.id_équipe=$e;";
            cmd.Parameters.AddWithValue("$e", idÉquipe);

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Joueur
                    {
                    Id = rd.GetInt32(0),
                    Nom = rd.GetString(1),
                    Licence = rd.IsDBNull(2) ? "" : rd.GetString(2),
                    Club = rd.IsDBNull(3) ? "" : rd.GetString(3)
                    });
                }
            return liste;
            }

        public static void RetirerJoueurDeÉquipe(int idÉquipe, int idJoueur)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM équipes_joueurs WHERE id_équipe=$e AND id_joueur=$j;";
            cmd.Parameters.AddWithValue("$e", idÉquipe);
            cmd.Parameters.AddWithValue("$j", idJoueur);
            cmd.ExecuteNonQuery();
            }
        }
    }
