﻿namespace TXM.Infrastructure.Services
    {
    public static class Service_Concours
        {
        public static IList<Concours> Lister_Concours(string type)
            {
            var liste = new List<Concours>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT id, nom, date, type 
                                FROM concours 
                                WHERE type=$type 
                                ORDER BY date DESC;";
            cmd.Parameters.AddWithValue("$type", type);

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Concours
                    {
                    Id = rd.GetInt32(0),
                    Nom = rd.GetString(1),
                    Date = DateTime.TryParse(rd.GetString(2), out var d) ? d : DateTime.MinValue,
                    Type = rd.GetString(3)
                    });
                }
            return liste;
            }

        public static Concours? Ajouter_Concours(string nom, DateTime date, string type)
            {
            if (!Service_Restrictions.PeutAjouterConcours())
                return null;

            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO concours(nom, date, type) 
                        VALUES($nom, $date, $type);
                        SELECT last_insert_rowid();";
            cmd.Parameters.AddWithValue("$nom", nom);
            cmd.Parameters.AddWithValue("$date", date.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("$type", type);
            var id = Convert.ToInt32(cmd.ExecuteScalar());

            return new Concours { Id = id, Nom = nom, Date = date, Type = type };
            }

        public static void Supprimer(int idConcours)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"DELETE FROM concours WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", idConcours);
            cmd.ExecuteNonQuery();
            }
        }
    }
