﻿using Microsoft.Data.Sqlite;
using TXM.Infrastructure.Base_de_données;
using TXM.Domaine.Modèles;

namespace TXM.Infrastructure.Services
    {
    public static class Service_Utilisateurs
        {
        public static Utilisateur? Obtenir_Par_Email(string email)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT id, nom, email, rôle, motdepasse
FROM users
WHERE email = $email;";
            cmd.Parameters.AddWithValue("$email", email);
            using var rd = cmd.ExecuteReader();
            if (!rd.Read()) return null;

            return new Utilisateur
                {
                Id = rd.GetInt32(0),
                Nom = rd.IsDBNull(1) ? "" : rd.GetString(1),
                Email = rd.IsDBNull(2) ? "" : rd.GetString(2),
                Rôle = rd.IsDBNull(3) ? "" : rd.GetString(3),
                MotDePasseHash = rd.IsDBNull(4) ? "" : rd.GetString(4)
                };
            }
        }
    }
