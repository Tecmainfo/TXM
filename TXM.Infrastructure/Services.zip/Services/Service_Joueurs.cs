﻿using TXM.Domaine.Modèles;

namespace TXM.Infrastructure.Services
    {
    public static class Service_Joueurs
        {
        public static IList<Joueur> ListerTous()
            {
            var liste = new List<Joueur>();
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT id, nom, licence, club 
                                FROM joueurs 
                                ORDER BY nom;";

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                {
                liste.Add(new Joueur
                    {
                    Id = rd.GetInt32(0),
                    Nom = rd.GetString(1),
                    Licence = rd.IsDBNull(2) ? "" : rd.GetString(2),
                    Club = rd.IsDBNull(3) ? "" : rd.GetString(3)
                    });
                }
            return liste;
            }

        public static int Compter()
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM joueurs;";
            return Convert.ToInt32(cmd.ExecuteScalar());
            }

        public static bool Ajouter(string nom, string licence = "", string club = "")
            {
            // Vérification via la passerelle centralisée
            if (!Service_Restrictions.PeutAjouterJoueur())
                return false; // rien ajouté en mode restreint si limite atteinte

            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO joueurs(nom, licence, club) 
                                VALUES($n, $l, $c);";
            cmd.Parameters.AddWithValue("$n", nom);
            cmd.Parameters.AddWithValue("$l", string.IsNullOrWhiteSpace(licence) ? "" : licence);
            cmd.Parameters.AddWithValue("$c", string.IsNullOrWhiteSpace(club) ? "" : club);
            cmd.ExecuteNonQuery();
            return true;
            }

        public static void Supprimer(int id)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM joueurs WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", id);
            cmd.ExecuteNonQuery();
            }

        public static void MettreÀJour(int id, string nom, string licence, string club)
            {
            using var conn = Service_SQLite.Ouvrir();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE joueurs 
                                SET nom=$n, licence=$l, club=$c 
                                WHERE id=$id;";
            cmd.Parameters.AddWithValue("$id", id);
            cmd.Parameters.AddWithValue("$n", nom);
            cmd.Parameters.AddWithValue("$l", string.IsNullOrWhiteSpace(licence) ? "" : licence);
            cmd.Parameters.AddWithValue("$c", string.IsNullOrWhiteSpace(club) ? "" : club);
            cmd.ExecuteNonQuery();
            }
        }
    }
