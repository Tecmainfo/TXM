﻿using System;
using System.Collections.Generic;
using System.Linq;

using TXM.Domaine.Modèles;

namespace TXM.Infrastructure.Services
    {
    public static class Service_Tirage
        {
        private static readonly Random _rng = new();

        public static void GénérerMatchesPremierTour(int idConcours, IList<Inscription> inscriptions)
            {
            // On mélange la liste
            var shuffled = inscriptions.OrderBy(x => _rng.Next()).ToList();

            // Pairer les équipes 2 par 2
            int tour = 1;
            for (int i = 0; i < shuffled.Count; i += 2)
                {
                if (i + 1 < shuffled.Count)
                    {
                    var equipeA = shuffled[i].NomÉquipe;
                    var equipeB = shuffled[i + 1].NomÉquipe;
                    Service_Matches.Enregistrer(idConcours, tour, equipeA, equipeB);
                    }
                else
                    {
                    // Équipe sans adversaire -> qualifiée d’office
                    var equipeA = shuffled[i].NomÉquipe;
                    Service_Matches.Enregistrer(idConcours, tour, equipeA, "Exempt");
                    }
                }
            }
        public static void GénérerTourSuivant(int idConcours, int tourActuel)
            {
            // Récupérer les matches du tour actuel
            var matches = Service_Matches.Lister(idConcours)
                                         .Where(m => m.Tour == tourActuel)
                                         .ToList();

            // Identifier les vainqueurs
            var qualifiés = matches.Where(m => m.Vainqueur != null)
                                   .Select(m => m.Vainqueur!)
                                   .ToList();

            if (qualifiés.Count < 2)
                return; // pas assez pour un nouveau tour

            int prochainTour = tourActuel + 1;

            // Tirage simple : appariement dans l'ordre
            for (int i = 0; i < qualifiés.Count; i += 2)
                {
                if (i + 1 < qualifiés.Count)
                    {
                    Service_Matches.Enregistrer(idConcours, prochainTour,
                                                qualifiés[i], qualifiés[i + 1]);
                    }
                else
                    {
                    // exempt → passe direct
                    Service_Matches.Enregistrer(idConcours, prochainTour,
                                                qualifiés[i], "Exempt");
                    }
                }
            }

        }
    }
