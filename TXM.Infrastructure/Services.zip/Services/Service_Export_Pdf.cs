﻿namespace TXM.Infrastructure.Services
    {
    public static class Service_Export_Pdf
        {
        public static string Exporter_Incidents(IEnumerable<Incident> incidents)
            {
            if (Service_Licence.EstEnModeRestreint())
                {
                throw new InvalidOperationException("Les exports sont désactivés en mode Démo restreint.");
                }

            var doc = new PdfDocument();
            doc.Info.Title = "Registre des incidents";

            var page = doc.AddPage();
            var gfx = XGraphics.FromPdfPage(page);
            var fontTitre = new XFont("Arial", 16, XFontStyle.Bold);
            var fontTexte = new XFont("Arial", 10);

            gfx.DrawString("Registre des incidents", fontTitre, XBrushes.Black,
                new XRect(0, 20, page.Width, 40), XStringFormats.TopCenter);

            int y = 80;
            foreach (var inc in incidents)
                {
                var ligne = $"{inc.Date:dd/MM/yyyy HH:mm} – {inc.Description} (Gravité: {inc.Gravité}) Arbitre:{inc.Arbitre}";
                gfx.DrawString(ligne, fontTexte, XBrushes.Black,
                    new XRect(40, y, page.Width - 80, 20), XStringFormats.TopLeft);

                y += 20;
                if (y > page.Height - 40)
                    {
                    page = doc.AddPage();
                    gfx = XGraphics.FromPdfPage(page);
                    y = 40;
                    }
                }

            var chemin = Path.Combine(Path.GetTempPath(), $"Incidents_{DateTime.Now:yyyyMMddHHmmss}.pdf");
            doc.Save(chemin);
            return chemin;
            }

        public static string Exporter_Sanctions(IEnumerable<Sanction> sanctions)
            {
            if (Service_Licence.EstEnModeRestreint())
                {
                throw new InvalidOperationException("Les exports sont désactivés en mode Démo restreint.");
                }

            var doc = new PdfDocument();
            doc.Info.Title = "Registre des sanctions";

            var page = doc.AddPage();
            var gfx = XGraphics.FromPdfPage(page);
            var fontTitre = new XFont("Arial", 16, XFontStyle.Bold);
            var fontTexte = new XFont("Arial", 10);

            gfx.DrawString("Registre des sanctions", fontTitre, XBrushes.Black,
                new XRect(0, 20, page.Width, 40), XStringFormats.TopCenter);

            int y = 80;
            foreach (var s in sanctions)
                {
                var ligne = $"{s.Date:dd/MM/yyyy HH:mm} – {s.Type} ({s.Motif}) [Art:{s.Article_Règlement}] Arbitre:{s.Arbitre} Durée:{s.Durée_Minutes} min";
                gfx.DrawString(ligne, fontTexte, XBrushes.Black,
                    new XRect(40, y, page.Width - 80, 20), XStringFormats.TopLeft);

                y += 20;
                if (y > page.Height - 40)
                    {
                    page = doc.AddPage();
                    gfx = XGraphics.FromPdfPage(page);
                    y = 40;
                    }
                }

            var chemin = Path.Combine(Path.GetTempPath(), $"Sanctions_{DateTime.Now:yyyyMMddHHmmss}.pdf");
            doc.Save(chemin);
            return chemin;
            }

        public static string Exporter_Tableau(IEnumerable<Match> matches, string nomConcours)
            {
            if (Service_Licence.EstEnModeRestreint())
                {
                throw new InvalidOperationException("Les exports sont désactivés en mode Démo restreint.");
                }

            var doc = new PdfDocument();
            doc.Info.Title = $"Tableau {nomConcours}";

            var page = doc.AddPage();
            var gfx = XGraphics.FromPdfPage(page);
            var fontTitre = new XFont("Arial", 16, XFontStyle.Bold);
            var fontTexte = new XFont("Arial", 10);

            gfx.DrawString($"Tableau de compétition – {nomConcours}",
                fontTitre, XBrushes.Black,
                new XRect(0, 20, page.Width, 40),
                XStringFormats.TopCenter);

            int y = 80;
            int tourActuel = -1;

            foreach (var match in matches.OrderBy(m => m.Tour).ThenBy(m => m.Id))
                {
                if (match.Tour != tourActuel)
                    {
                    tourActuel = match.Tour;
                    gfx.DrawString($"--- Tour {tourActuel} ---",
                        fontTexte, XBrushes.DarkBlue,
                        new XRect(40, y, page.Width - 80, 20),
                        XStringFormats.TopLeft);
                    y += 20;
                    }

                var ligne = $"{match.EquipeA} ({match.ScoreA}) vs {match.EquipeB} ({match.ScoreB})";
                gfx.DrawString(ligne, fontTexte, XBrushes.Black,
                    new XRect(60, y, page.Width - 100, 20),
                    XStringFormats.TopLeft);
                y += 20;

                if (y > page.Height - 40)
                    {
                    page = doc.AddPage();
                    gfx = XGraphics.FromPdfPage(page);
                    y = 40;
                    }
                }

            var chemin = Path.Combine(Path.GetTempPath(),
                $"Tableau_{nomConcours}_{DateTime.Now:yyyyMMddHHmmss}.pdf");
            doc.Save(chemin);
            return chemin;
            }

        }
    }
